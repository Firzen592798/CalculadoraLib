package main;

@SuppressWarnings("serial")
public class DivisaoPorZeroException extends Exception {

	public DivisaoPorZeroException() {
		super();

	}

}
